# Portfolio Website Deployment Guide

This guide will help you deploy your interactive portfolio website to Vercel for free.

## Prerequisites
- GitHub account
- Vercel account (free)
- Git installed on your computer

## Files You Need

Your portfolio website includes these key files:
- `index.html` - Main HTML structure
- `style.css` - All styling and responsive design
- `app.js` - Interactive functionality for flashcards and projects
- `vercel.json` - Vercel deployment configuration (create this)
- `package.json` - Project metadata (create this)

## Step 1: Create Additional Files

### 1. Create `vercel.json` in your root directory:
```json
{
  "version": 2,
  "builds": [
    {
      "src": "index.html",
      "use": "@vercel/static"
    }
  ],
  "routes": [
    {
      "src": "/(.*)",
      "dest": "/index.html"
    }
  ]
}
```

### 2. Create `package.json` in your root directory:
```json
{
  "name": "portfolio-website",
  "version": "1.0.0",
  "description": "Interactive developer portfolio with flashcards and project slides",
  "main": "index.html",
  "scripts": {
    "dev": "http-server -p 3000",
    "start": "http-server -p 8080"
  },
  "keywords": ["portfolio", "developer", "interactive", "web"],
  "author": "Arham Kelkar",
  "license": "MIT",
  "devDependencies": {
    "http-server": "^14.1.1"
  }
}
```

## Step 2: Customize Your Portfolio

Before deploying, customize the content in your files:

### In `index.html`:
- Replace "Arham Kelkar" with your actual name
- Update the bio and description
- Add your actual social media links
- Update contact information

### In `app.js`:
- Update the skills data with your actual skills
- Modify project information with your real projects
- Update experience and education details
- Add your actual GitHub and project URLs

### In `style.css`:
- Customize colors if needed (see CSS custom properties at the top)
- Adjust any styling preferences

## Step 3: Create GitHub Repository

1. Go to GitHub and create a new repository
2. Name it something like `portfolio-website` or `my-portfolio`
3. Initialize with README (optional)

## Step 4: Upload Your Files

### Option A: Using Git Command Line
```bash
# Clone your repository
git clone https://github.com/yourusername/your-repo-name.git

# Navigate to the folder
cd your-repo-name

# Add your files (copy all the portfolio files here)
# Add the vercel.json and package.json files you created

# Commit and push
git add .
git commit -m "Initial portfolio website"
git push origin main
```

### Option B: Using GitHub Web Interface
1. Go to your repository on GitHub
2. Click "uploading an existing file"
3. Drag and drop all your portfolio files
4. Commit the changes

## Step 5: Deploy to Vercel

### Method 1: Vercel Dashboard (Recommended)
1. Go to [vercel.com](https://vercel.com) and sign in
2. Click "New Project"
3. Import your GitHub repository
4. Vercel will automatically detect it's a static site
5. Click "Deploy"
6. Wait for deployment to complete
7. Your site will be live at `https://your-project-name.vercel.app`

### Method 2: Vercel CLI
```bash
# Install Vercel CLI globally
npm install -g vercel

# Login to Vercel
vercel login

# Deploy from your project directory
vercel

# Follow the prompts
```

## Step 6: Set Up Automatic Deployments

Once connected to GitHub, Vercel will automatically:
- Deploy your main branch to production
- Create preview deployments for pull requests
- Redeploy when you push changes to main

## Features of Your Portfolio

### Interactive Skills Flashcards
- Hover or click on skill cards to flip them
- Front: Skill name and icon
- Back: Proficiency level, experience, and description
- Filter by categories: Programming Languages, Frameworks, Tools, etc.

### Project Slides with Dropdowns
- Click on project cards to expand details
- Dropdown shows: Full description, technologies, key features
- Links to live demos and GitHub repositories
- Smooth animations for expand/collapse

### Other Features
- Dark/Light theme toggle
- Responsive design for all devices
- Smooth scrolling navigation
- Contact form (front-end only)
- SEO optimized
- Fast loading performance

## Customization Tips

1. **Colors**: Modify CSS custom properties in `style.css`
2. **Content**: Update data in `app.js` and HTML content
3. **Skills**: Add/remove skills in the `skillsData` array
4. **Projects**: Modify the `projectsData` array with your projects
5. **Images**: Replace placeholder images with your actual project screenshots

## Performance Optimization

Your site is already optimized with:
- Minified CSS and JavaScript
- Optimized images (use WebP format when possible)
- Lazy loading for images
- Efficient CSS animations
- Mobile-first responsive design

## Domain Setup (Optional)

To use your own domain:
1. Go to your Vercel dashboard
2. Select your project
3. Go to Settings → Domains
4. Add your custom domain
5. Update your domain's DNS settings

## Troubleshooting

### Common Issues:
1. **Build fails**: Check file paths and syntax errors
2. **Site not loading**: Verify index.html is in root directory
3. **Styles not working**: Check CSS file path in HTML
4. **JavaScript errors**: Check browser console for details

### Support Resources:
- [Vercel Documentation](https://vercel.com/docs)
- [GitHub Help](https://help.github.com)
- Check browser console for JavaScript errors
- Verify all file paths are correct

## Security Notes

- Never commit sensitive information (API keys, passwords)
- Use environment variables for any sensitive data
- The contact form is front-end only - consider adding a backend service

## Next Steps

After deployment:
1. Test all functionality on the live site
2. Share your portfolio URL on LinkedIn and GitHub
3. Add the portfolio link to your resume
4. Consider adding Google Analytics for insights
5. Regularly update with new projects and skills

Your portfolio is now live and ready to impress potential employers and clients!